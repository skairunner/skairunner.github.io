CONTROLS
=+=+=+=+=+=+=+=
<WORLD MAP>
Arrow keys	|	scroll
>	|	continue to end of path
.	|	let one day pass
k	|	view skills
S	|	view ships
s	|	(when the fleet is on a tile with a town in it) enter town menu
t	|	(debug) show city generation trails
Y	|	lock/unlock camera to player fleet or moused-over NPC ship
z	|	(debug) show city ZoCs
=+=+=+=+=+=+=+=
The rest should be self-evident once you enter menus. Most windows can be canceled out of with ESCAPE, and Yes/No prompts can be Yes'd with ENTER and No'd with ESCAPE. The World Map controls are usually case-sensitive; window controls are usually not.